<?php
/**
 * Created by PhpStorm.
 * User: heqing
 * Date: 15/7/31
 * Time: 09:42
 */

return array(
    'info' => array(
        'name' => 'Apply',
        'title' => '报名',
        'description' => '报名插件',
        'status' => 1,
        'author' => 'better',
        'version' => '0.1'
    ),
);