DROP TABLE IF EXISTS `wemall_addon_apply_config`;
DROP TABLE IF EXISTS `wemall_addon_apply_record`;
DROP TABLE IF EXISTS `wemall_addon_apply_contact`;